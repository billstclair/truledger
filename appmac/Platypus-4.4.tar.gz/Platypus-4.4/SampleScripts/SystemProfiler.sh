#!/bin/sh
#
# System profiler report in text
#
# Load this script into Platypus, select "Requires Admin privileges" and 
# "Remain running after completion" and set Ouput to Text Window
# Then press create. 
#

/usr/sbin/system_profiler